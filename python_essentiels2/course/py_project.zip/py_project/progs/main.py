from sys import path
# path.append('..∖∖packages') #for windows
path.append('..//packages')


import extra.iota
print(extra.iota.FunI())


# second version 
#from extra.iota import funI
#print(funI())


# third version with aliases
# import extra.good.best.sigma as sig
# import extra.good.alpha as alp

# print(sig.funS())
# print(alp.funA())





